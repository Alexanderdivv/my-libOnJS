//isi titik-titik dibawah ini ya
//buat object dengan nama ruang
var ... = {
  tipe: "Balok",
  ...: "...", //deskripsikan properties warnanya
  sisi: ..., //coba deskripsikan banyak sisinya
  panjang: 10,
  lebar: 5,
  tinggi: 4
};
//coba akses nilai dari panjang, lebar dan tinggi
//buat agar console menampilkan volume balok
console.log(...............................);
//buat agar console menampilkan volume balok
//sekarang gunakan function untuk menampilkan volumenya
function volume(){
  return "Volume balok adalah: " + ...........;
}
console.log(volume());